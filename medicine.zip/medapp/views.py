from django.shortcuts import render
import cv2
from .models import aspirin,meddetails
######################################
import pytesseract
from PIL import Image
import io
#####################################
#Create your views here.
def home(request):
    return render(request,'index.html')
def search(request):
    catch=request.POST.get('search')
    show=aspirin.objects.filter(generic=catch)
    return render(request,'base.html',{'show':show,'catch':catch})
def data(request):
    
    value=request.POST.get('gen')
    show=meddetails.objects.filter(generic=value)
    return render(request,'result.html',{'show':show})
def camera1(request):
    vid = cv2.VideoCapture(0)
    while(True):
        ret, frame = vid.read()
        cv2.imshow('frame', frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cv2.imwrite(r"C:\Users\FABHOSTPYTHON\Desktop\medicine\medapp\images\out1.jpg" , frame)
    vid.release()
    cv2.destroyAllWindows()
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
    image_data =cv2.imread(r"C:\Users\FABHOSTPYTHON\Desktop\medicine\medapp\images\out1.jpg")
    
    
    catch=pytesseract.image_to_string(image_data).strip
    print(catch)
  
    
    return render(request,'index1.html',{'catch':catch})
def tesout(request):
    out=request.POST.get('search1')
    print(out,'catch')
    show=aspirin.objects.filter(generic=out)
    print("hello",show)
    return render(request,'base.html',{'show':show})
    