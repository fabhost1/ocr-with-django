from django.db import models

# Create your models here.
class aspirin(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'aspirin'
class Bcomplex(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'Bcomplex'
class Calamine(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'calamine'
class BACAMPICILLIN(models.Model): 
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'BACAMPICILLIN'
class meddetail(models.Model): 
    generic=models.TextField(max_length=20)
    uses=models.TextField(max_length=1000)
    sideeffects=models.TextField(max_length=1000)
class meddetails(models.Model): 
    generic=models.TextField(max_length=20)
    uses=models.TextField(max_length=1000)
    sideeffects=models.TextField(max_length=1000)
    class Meta:
        db_table = 'meddetails'
   